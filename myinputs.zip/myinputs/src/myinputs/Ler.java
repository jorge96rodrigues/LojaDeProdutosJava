/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myinputs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author jorgemiguelamorosorodrigues
 */
public class Ler {
    public static String umaString (){
 String s = "";
 try{
 BufferedReader in = new BufferedReader ( new InputStreamReader (System.in));
 s= in.readLine();
 }
 catch (IOException e){
 System.out.println("Erro ao ler fluxo de entrada.");
 }
 return s;
}
    
    public static int umInt(){
while(true){
try{
return Integer.valueOf(umaString().trim()).intValue();
}
catch(Exception e){
System.out.println("Não é um inteiro válido!!!");
}
}
}
    
    public static double umDouble(){
while(true){
try{
return Double.valueOf(umaString().trim()).intValue();
}
catch(Exception e){
System.out.println("Não é um Decimal válido válido!!!");
}
}
}
    
        public static long umLong(){
while(true){
try{
return Long.valueOf(umaString().trim()).intValue();
}
catch(Exception e){
System.out.println("Não é um numero válido!!!");
}
}
}
        
  

}
