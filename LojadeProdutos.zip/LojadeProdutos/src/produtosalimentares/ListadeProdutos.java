/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produtosalimentares;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author JorgeRodrigues
 */
public class ListadeProdutos implements Serializable{ //Stock
        
    protected ArrayList<Produto> listadeprodutos;
    private  int contadorcodigodebarras;
    private int[]stock;
//--------------------------------------------------------------------------
//construtor
    public ListadeProdutos(){
        listadeprodutos=new ArrayList<Produto>();
        this.contadorcodigodebarras=1;
        this.stock=new int[999999];
  
    }

    public void setListadeprodutos(ArrayList<Produto> listadeprodutos) {
        this.listadeprodutos = listadeprodutos;
    }

    public void setContadorcodigodebarras(int contadorcodigodebarras) {
        this.contadorcodigodebarras = contadorcodigodebarras;
    }

    public void setStock(int[] stock) {
        this.stock = stock;
    }

    public ArrayList<Produto> getListadeprodutos() {
        return listadeprodutos;
    }

    public int getContadorcodigodebarras() {
        return contadorcodigodebarras;
    }

    public int[] getStock() {
        return stock;
    }
//--------------------------------------------------------------------------   
    public void insereCodigodeBarras(){
        for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigodebarras()==0){
            listadeprodutos.get(i).setCodigodeBarras(contadorcodigodebarras);
            this.contadorcodigodebarras=contadorcodigodebarras+1;
            }
        }
    }
    
    public void removeProduto(int codigodebarras) {
        for (int i = 0; i < listadeprodutos.size(); i++) {
            if (listadeprodutos.get(i).getCodigodebarras() == codigodebarras) {
                listadeprodutos.remove(i);
            }
        }

    }
    
    
    public void Stock(){
       ArrayList<Produto> copia=(ArrayList<Produto>) listadeprodutos.clone();
       this.stock=new int[9999999];
        
        for(int i=0;i<listadeprodutos.size();i++){
            if(copia.get(i).getCodigo()==listadeprodutos.get(i).getCodigo()){
                int codigo=(int) listadeprodutos.get(i).getCodigo();
                this.stock[codigo]=stock[codigo]+1;
            }
        }
        
        for(int i=0;i<listadeprodutos.size();i++){
            int codigo2=(int) listadeprodutos.get(i).getCodigo();
            this.listadeprodutos.get(i).setStock(stock[codigo2]);
        }
    }
    
    public void alterarNome(int codigo, String novonome){
        for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo()==codigo){
                listadeprodutos.get(i).setProduto(novonome);
            }
        }
    }
    
    public void alteraCodigo(int codigo,int novocodigo){
      for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo()==codigo){
                listadeprodutos.get(i).setCodigo(novocodigo);
            }
        }
    
    }
    
    public void alteraPreço(int codigo,int novopreco){
      for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo()==codigo){
                listadeprodutos.get(i).setPreco(novopreco);
            }
        }
    
    }
    
    
    public void eliminarLote(int codigo){
        for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo()==codigo){
                listadeprodutos.remove(i);
            }
        }
    }
    
    public String alertaValidade(int dia,int mes,int ano){
        int lancaalerta=0;
        String foradevalidade="             >>> ALERTA <<<           \n         PRODUTOS FORA DE VALIDADE.: \n";
                
        for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getDia()==dia && listadeprodutos.get(i).getMes()==mes
                    && listadeprodutos.get(i).getAno()==ano){
                lancaalerta=lancaalerta+1;
                foradevalidade=foradevalidade+"Nome do Produto.: "+listadeprodutos.get(i).getProduto()+
                        "| Codigo de Barras.:"+listadeprodutos.get(i).getCodigodebarras()+"\n";
                
           }
        }
        for(int j=0;j<3;j++){
        for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getDia()==dia && listadeprodutos.get(i).getMes()==mes
                    && listadeprodutos.get(i).getAno()==ano){
                listadeprodutos.remove(i);
            
                
           }
        }
    }
        
        foradevalidade=foradevalidade+" >>> OS PRODUTOS VÃO SER ELIMINADOS DO PROGRAMA!!! <<< ";
        
        if(lancaalerta==0){
            foradevalidade="";
        
        }
    
    
    return foradevalidade;
    
    }
    
    
    public boolean verificaCodigoBarras(int codigodebarras){
    for(int i=0;i<listadeprodutos.size();i++){
        if(listadeprodutos.get(i).getCodigodebarras()==codigodebarras){
            return true;
        
        }
    
    }
    
    
    return false;
    }
    
    
    
    public String ListadeStock(){
        String listadestock="";
        
        for(int i=0;i<stock.length;i++){
            if(stock[i]!=0){
                String produtostock=NomeaPartirdeCodigo(i);
                listadestock=listadestock+"Produto.: "+produtostock+" | "+"Stock.: "+stock[i]+"\n";
            }
        
        }
    
    return listadestock;
    }
    
    public String NomeaPartirdeCodigo(int codigo){
        String nome="";
        for(int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo()==codigo){
                nome=listadeprodutos.get(i).getProduto();
            }
        
        }
    
    return nome;
    }

    
//--------------------------------------------------------------------------
//adiciona produtos
    public void adicionaProduto(Produto a){
        listadeprodutos.add(a);
    }
    
    public String   avisodeStock(){
        String reporstock="";
        for(int i=0;i<listadeprodutos.size();i++){
            if(stock[i]!=0 && stock[i]<=10){
                reporstock=reporstock+"ATENÇÃO.: REPOR.: "+NomeaPartirdeCodigo(i)+"\n";
            }
        }
        
     return reporstock;
    }
        
    
    //--------------------------------------------------------------------------
    
    
    //--------------------------------------------------------------------------
    // Para usar na fatura retorna produto introduzindo o código
    public Produto retornaProduto(int codigo){
        Produto a=new Produto();
        
        for (int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo()==codigo){
                a=(Produto) listadeprodutos.clone();
               
            }
        
        }
     return a;
    }
//--------------------------------------------------------------------------
// verifica se o produto existe
    public boolean verificaProduto(Produto a){
        for (int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).equals(a)){
               return true;
            }
        }
        return false;
    }
    
    
     public boolean verificaCodigo(int codigo){
        for (int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getCodigo() == codigo) {
               return true;
            }
        }
        return false;
    }
    

     
         public double encontrarPreco(int codigo) {
         
             double preco = 0.0;
         
         for (int i = 0; i < listadeprodutos.size(); i++) {
             
              if(listadeprodutos.get(i).getCodigo() == codigo) {
                  
                  preco = listadeprodutos.get(i).getPreco();
                  
              }
             
         }
            
         return preco;
     }
         
     
       
         
        
    
    
//------------------------------------------------------------------------------
//pesquisa pelo nome
    public boolean verificaNome(String nomeproduto){
    for (int i=0;i<listadeprodutos.size();i++){
            if(listadeprodutos.get(i).getProduto().compareTo(nomeproduto)==0){
               return true;
            }
        }
        return false;
    
    }
//--------------------------------------------------------------------------
// ver stock
//    public int quantosExistem(Produto a){
//    int quantos=0;
//        for (int i=0;i<listadeprodutos.size();i++){
//            if(listadeprodutos.get(i).equals(a)){
//               quantos=quantos+1;
//            }
//        }
//    return quantos;
//    }
    
//------------------------------------------------------------------------------
  
//--------------------------------------------------------------------------
public String toString(){
   String lista="";
    for(int i=0;i<listadeprodutos.size();i++){
    lista=lista+listadeprodutos.get(i)+" \n ";
            }
    return "Lista de Produtos.: \n\n"+lista;
            

}
    
} 
