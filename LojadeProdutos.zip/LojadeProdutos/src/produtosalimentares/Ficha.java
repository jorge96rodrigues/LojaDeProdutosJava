/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produtosalimentares;

import java.io.Serializable;

/**
 *
 * @author JorgeRodrigues
 */
public class Ficha implements Serializable {

    private String nome;
    private long nif;
    private long contacto;
    private double comprasefectuadas;

//Construtores
    public Ficha() {
        nome = "";
        nif = 0;
        contacto = 0;
        comprasefectuadas=0.0;

    }

    public Ficha(String nome, long nif, long contacto) {
        this.nome = nome;
        this.nif = nif;
        this.contacto = contacto;
        this.comprasefectuadas=0.0;

    }
//------------------------------------------------------------------------------
//set's

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNif(long nif) {
        this.nif = nif;
    }

    public void setContacto(long contacto) {
        this.contacto = contacto;
    }
    
    public void setComprasEfectuadas(double comprasefectuadas){
        this.comprasefectuadas=comprasefectuadas;
    }
//------------------------------------------------------------------------------
//get's

    public String getNome() {
        return nome;
    }

    public long getNif() {
        return nif;
    }

    public long getContacto() {
        return contacto;
    }
    
    public double getComprasEfectuadas(){
        return comprasefectuadas;
    }
    
    //--------------------------------------------------------------------------
    // adiciona € da fatura para sabermos o melhor cliente
    public void adicionaCompra(double valor){
        this.comprasefectuadas=comprasefectuadas+valor;
       
    }
    
//------------------------------------------------------------------------------
//metodo equals

    public boolean equals(Object O) {
        if (O != null && getClass() == O.getClass()) {
            Ficha a = (Ficha) O;

            return (this.nome.equals(a.nome)
                    && this.nif == a.nif
                    && this.contacto == this.contacto
                    && this.comprasefectuadas==this.comprasefectuadas);
        }
        return false;
    }
//------------------------------------------------------------------------------
//metodo clone

    public Object clone() {
        Ficha copia = new Ficha(this.nome, this.nif, this.contacto);
        copia.comprasefectuadas=this.comprasefectuadas;
        return copia;
    }
//------------------------------------------------------------------------------
//metodo toString

    public String toString() {

        return "Nome.: " + nome + " | "
                + "NIF.: " + nif + " | "
                + "Contacto.: " + contacto + " | \n";
    }
//------------------------------------------------------------------------------

}
