package produtosalimentares;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author JorgeRodrigues
 */
public class Clientes implements Serializable{

    protected ArrayList<Ficha> clientes;

//Construtores
    public Clientes() {
        clientes = new ArrayList<Ficha>();
    }
//------------------------------------------------------------------------------
// set's

    public void setClientes(ArrayList<Ficha> clientes) {
        this.clientes = clientes;
    }

  
//------------------------------------------------------------------------------
//get's
 public ArrayList<Ficha> getClientes() {
        return clientes;
    }
//------------------------------------------------------------------------------
//adiciona cliente
 

  

    public void adicionaCliente(Ficha a) {
        if (verificaExiste(a) == false) {

            this.clientes.add(a);

        }
    }
    
    public void removeClienteNif(long nifremover){
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nifremover){
                clientes.remove(i);
            
            }     
        
        }
    }
    
    public String devolveNome(long nif){
        String clientedevolve=""; 
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nif){
                clientedevolve=clientes.get(i).getNome();
            
            }     
        
        }
    return clientedevolve;
            
    }
    
     public long devolveContacto(long nif){
        long devolvecontacto=0; 
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nif){
                devolvecontacto=clientes.get(i).getContacto();
            
            }     
        
        }
    return devolvecontacto;
            
    }
    
    public void alteraNome(long nif, String nomemodificado){
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nif){
                clientes.get(i).setNome(nomemodificado); 
            }
        
        }
    }
    
    
    public void alteraContacto(long nif, long contactonovo){
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nif){
                clientes.get(i).setContacto(contactonovo); 
            }
        
        }
    }
    
     public void alteraNif(long nif, long nifnovo){
        for(int i=0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nif){
                clientes.get(i).setNif(nifnovo); 
            }
        
        }
    }
//------------------------------------------------------------------------------
// dados do cliente numero x

    public String dadosCliente(long nif) {
        String dados="";
        for(int i =0;i<clientes.size();i++){
            if(clientes.get(i).getNif()==nif){
            dados="Nome.: "+clientes.get(i).getNome()+" | "+
                    "NIF.: "+nif+" | "+
                    "Contacto.: "+clientes.get(i).getContacto()+" | ";
            }
        
        }
        
        return  dados;
    }
//------------------------------------------------------------------------------

    
//------------------------------------------------------------------------------
//verifica se a ficha de cliente existe

    public boolean verificaExiste(Ficha a) {

        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).equals(a)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean verificaNIF(long nif){
         for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getNif()==nif) {
                return true;
            }
         }
            return false;
    }
    
public boolean equals(Object O){
    if(O!=null && getClass()==O.getClass()){
        Clientes a =(Clientes)O;
      
        return (this.clientes.equals(a.clientes));
    
    
    }
    
    return false;
}

public Object clone(){
Clientes copia=new Clientes();
copia.clientes=this.clientes;

return copia;
}
//------------------------------------------------------------------------------
//metodo toString

    public String toString() {
        String sclientes = "";
        for (int i = 0; i < clientes.size(); i++) {
            sclientes = sclientes + "Nº Cliente.: " + (i + 1) + "\n" + clientes.get(i) + "\n";// Marca o numero de cliente
        }

        return "Lista de Clientes.: \n" + sclientes ;

    }
//------------------------------------------------------------------------------

}
