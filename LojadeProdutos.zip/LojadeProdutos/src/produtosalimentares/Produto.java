/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produtosalimentares;

import java.io.Serializable;

/**
 *
 * @author JorgeRodrigues
 */
public class Produto implements Serializable {

    private String produto;// nome do produto
    private int codigo; // codigo do produto
    private int dia; // dia quando acaba a validade
    private int mes; // mes de quando acaba a validade
    private int ano; // ano de quando acaba a validade
    private double preco; //  preço do produto
    private int quantidade;
    private int codigodebarras;
    private int stock;

// construtores
    public Produto() {
        produto = "";
        codigo = 0;
        dia = 0;
        mes = 0;
        ano = 0;
        preco = 0.0;
        quantidade = 1;
        codigodebarras=0;
        stock=0;
    }

    public Produto(String produto, int codigo, int dia, int mes, int ano, double preco) {
        this.produto = produto;
        this.codigo = codigo;
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
        this.preco = preco;
      this.quantidade = quantidade;
      this.codigodebarras=0;
      this.stock=0;
      
    }
//------------------------------------------------------------------------------


    

    public void setCodigodebarras(int codigodebarras) {
        this.codigodebarras = codigodebarras;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setCodigodeBarras(int codigodebarras) {
        this.codigodebarras = codigodebarras;
    }

// set's 
    public void setProduto(String produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public int getCodigodebarras() {
        return codigodebarras;
    }

    public int getStock() {
        return stock;
    }
    public void setQuantidade(int quantidade) {
        
       this.quantidade = quantidade;
        
    }
   
    
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
//------------------------------------------------------------------------------
//get's 

    public String getProduto() {
        return produto;
    }

    public int getCodigo() {
        return codigo;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAno() {
        return ano;
    }

    public double getPreco() {
        return preco;
    }
    
 
    
    
    
    
//------------------------------------------------------------------------------
// metodo equals

    public boolean equals(Object O) {
        if (O != null && getClass() == O.getClass()) {
            Produto igual = (Produto) O;

            return (igual.produto.compareTo(this.produto) == 0
                    && igual.codigo == this.codigo
                    && igual.dia == this.dia
                    && igual.mes == this.mes && igual.ano == this.ano
                    && igual.preco == this.preco);
                //    && igual.quantidade == this.quantidade);
        }
        return false;
    }
    
    //--------------------------------------------------------------------------
    
   
//------------------------------------------------------------------------------
//metodo clone

    public Object clone() {
        Produto copia = new Produto(this.produto, this.codigo, this.dia, this.mes, this.ano, this.preco);
       // copia.quantidade = this.quantidade;
        return copia;
    
    }
//------------------------------------------------------------------------------    
//metodo toString    

    public String toString() {
        return "Produto.: " + produto + " | "
                + "Código.: " + codigo + " | "
                + "Preço.: " + preco + "€ | "
                + "Validade.: " + dia + "/" + mes + "/" + ano + " | "
                +"Código de Barras.: "+codigodebarras+" | "
                + "Stock.: " + stock + "\n";

    }
//------------------------------------------------------------------------------

}
