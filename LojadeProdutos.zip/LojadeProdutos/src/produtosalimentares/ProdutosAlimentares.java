/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produtosalimentares;

import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
import myinput.Ler;

/**
 *
 * @author JorgeRodrigues
 */
public class ProdutosAlimentares  {

    /**
     * @param args the command line argu'ments
     */
    public static void main(String[] args) {
        GregorianCalendar calendario= new GregorianCalendar();
        int mes=calendario.get(Calendar.MONTH)+1;
        int dia=calendario.get(Calendar.DAY_OF_MONTH);
        int ano=calendario.get(Calendar.YEAR);
        int ultimodomes=calendario.getActualMaximum( Calendar.DAY_OF_MONTH );
        
        // Introdução do programa 
        ListadeProdutos lojaprodutos;
        Clientes clientesloja;
        Faturacao faturasloja;
       
        clientesloja = new Clientes();//LISTA DE CLIENTES
        lojaprodutos = new ListadeProdutos();//LISTA DE PRODUTOS
        faturasloja = new Faturacao();//FATURAÇÃO DA LOJA(TODAS AS FATURAS)


        try{
       ObjectInputStream leprodutos = new ObjectInputStream(new FileInputStream("lojaprodutos.txt"));
       ObjectInputStream leclientes = new ObjectInputStream(new FileInputStream("lojaclientes.txt"));
       ObjectInputStream lefaturas = new ObjectInputStream(new FileInputStream("lojafaturas.txt"));
       
       lojaprodutos= (ListadeProdutos)leprodutos.readObject();
       clientesloja=(Clientes)leclientes.readObject();
       faturasloja=(Faturacao) lefaturas.readObject();

        leprodutos.close();
        leclientes.close();
        lefaturas.close();
        }catch(IOException a){
                
            System.out.println("Erro ao Ler o Ficheiro");
        }
        
        catch(ClassNotFoundException b){
            System.out.println("Erro ao Ler o Ficheiro");
        
        }




        


 
        System.out.println("");
        int menuinicial = 90;
        String limpar = limpaOutput();// inicializar a função para limpar o output

        while (menuinicial != 0) {
            System.out.println(limpar);//limpa o output
            System.out.println(">>>>> LOJA DE PRODUTOS ALIMENTARES <<<<<");
            System.out.println("*----------*---------------------------*");
            System.out.println("| OPCÕES.: |                           |");
            System.out.println("*----------*                           |");
            System.out.println("|   => Produtos      (1)               |");
            System.out.println("|   => Clientes      (2)               |");
            System.out.println("|   => Faturação     (3)               |");
            System.out.println("|   => Vendas        (4)               |");
            System.out.println("|   => Sair          (0)               |");
            System.out.println("*--------------------------------------*");
            System.out.println(lojaprodutos.alertaValidade(dia, mes, ano));
            System.out.print("OPCÃO LOJA.: ");
            
            //introdução da opção
            menuinicial = Ler.umInt();

            switch (menuinicial) {
                // OPCÂO PRODUTOS
                case 1:
                    System.out.println(limpar);//limpa o output
                    int menuprodutos;
                    String continuarprodutos = " ";
                    while (continuarprodutos.compareTo("N") != 0) {// vai ver se quer sair do menu produtos

                        System.out.println(limpar);//limpa o output
                        
                        System.out.println("*-------------------*------------------*");
                        System.out.println("| OPCÕES PRODUTOS.: |                  |");
                        System.out.println("*-------------------*                  |");
                        System.out.println("|   => Adicionar Produtos      (1)     |");
                        System.out.println("|   => Ver Lista de Produtos   (2)     |");
                        System.out.println("|   => Modificar Produto       (3)     |");
                        System.out.println("|   => Eliminar Produto        (4)     |");
                        System.out.println("|   => Ver se Existe na Loja   (5)     |");
                        System.out.println("|   => Stock Existente         (6)     |");
                        System.out.println("|   => Sair do menu Prudtos    (0)     |");
                        System.out.println("*--------------------------------------*");

                        System.out.print("OPCÃO PRODUTOS.: ");
                        menuprodutos = Ler.umInt();// ve a opcao escolhida

                        System.out.println(limpar);//limpa o output

                        switch (menuprodutos) {
                            //-----------------------  CASE 1 PRODUTOS -----------------------------
                            case 1:
                                //INTRODUZIR PRODUTOS
                                String continuar = "";

                                while (continuar.compareTo("N") != 0) {
                                    
                                    Produto novo;
                                    String nome = "";
                                    int codigo ,quantidade;
                                    int validadedia=5000;
                                    int validadeano=1;
                                    int validademes=50;
                                    double preco;
                                    System.out.print("Código.:");
                                    codigo=Ler.umInt();
                                   
                              
                                    
                                    if (lojaprodutos.verificaCodigo(codigo)) {
                                     
                                    System.out.print("Quantidade.: ");
                                    quantidade=Ler.umInt();
                                    System.out.println("Validade.: ");//validade
                                    
                                    
                                    while(validadeano<2016 || validadeano>2080){
                                    System.out.print("Ano.: ");//pede o ano
                                    validadeano = Ler.umInt();
                                    }
                                    while(validademes>12 || validademes<=0){
                                    System.out.print("Mês.: ");//pede o mes
                                    validademes = Ler.umInt();
                                    }
                                    if(anoBicesto(validadeano) && validademes==2){
                                    while(validadedia>29 || validadedia<=0){
                                    System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    if(anoBicesto(validadeano)==false && validademes==2){
                                    while(validadedia>28 || validadedia<=0){
                                   System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    if(diasMes(validademes)==30){
                                    while(validadedia > 30 || validadedia<=0){
                                    System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    if(diasMes(validademes)==31){
                                    while(validadedia > 31 || validadedia<=0){
                                    System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    
                                    
                                    nome = lojaprodutos.NomeaPartirdeCodigo(codigo);
                                    preco = lojaprodutos.encontrarPreco(codigo);
                                    
                                    for(int i=0;i<quantidade;i++){        
                                    novo = new Produto(nome, codigo, validadedia, validademes, validadeano, preco);// introduz o pedido no objecto Produto
                                    lojaprodutos.adicionaProduto(novo);// vai adicionar o Produto á lista de produtos
                                    }
                                    }
                                   
                                    else {
                                    System.out.print("Quantidade.: ");
                                    quantidade=Ler.umInt();
                                    System.out.print("\nNome do Produto.: ");//pede o nome
                                    nome = Ler.umaString();
                                   
                                    System.out.print("Preço.: ");//pede o preço
                                    preco = Ler.umDouble();
                                              System.out.println("Validade.: ");//validade
                                    
                                    
                                    while(validadeano<2016 || validadeano>2080){
                                    System.out.print("Ano.: ");//pede o ano
                                    validadeano = Ler.umInt();
                                    }
                                    
                                    while(validademes>12 || validademes<=0){
                                    System.out.print("Mês.: ");//pede o mes
                                    validademes = Ler.umInt();
                                    }
                                    if(anoBicesto(validadeano) && validademes==2){
                                    while(validadedia>29 || validadedia<=0){
                                    System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    if(anoBicesto(validadeano)==false && validademes==2){
                                    while(validadedia>28 || validadedia<=0){
                                   System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    if(diasMes(validademes)==30){
                                    while(validadedia > 30 || validadedia<=0){
                                    System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    if(diasMes(validademes)==31){
                                    while(validadedia > 31 || validadedia<=0){
                                    System.out.print("Dia.: ");//pede o dia
                                    validadedia = Ler.umInt();
                                    }
                                    }
                                    
                                    for(int i=0;i<quantidade;i++){
                                    novo = new Produto(nome, codigo, validadedia, validademes, validadeano, preco);// introduz o pedido no objecto Produto
                                    lojaprodutos.adicionaProduto(novo);// vai adicionar o Produto á lista de produtos
                                    }
                                    }
                                    
                                    lojaprodutos.insereCodigodeBarras();
                                    System.out.print("\nContinuar a Introduzir PRODUTOS (Y/N): ");
                                    continuar = Ler.umaString();

                                    System.out.println(limpar);//limpa o output

                                    //----------------------------------------------------------------
                                }
                                lojaprodutos.Stock();
                                break;
                        //*********************  FIM CASE 1 PRODUTOS  **************************

                            //********************** CASE 2 PRODUTOS  ******************************
                            case 2:
                                
                                System.out.println(lojaprodutos.toString());

                                break;
                                
                            case 3:
                                int opcaomodificar=100;
                                while(opcaomodificar!=0){
                                System.out.println(limpar);//limpa o output
                                System.out.println("*-------------*-----------------*");
                                System.out.println("| MODIFICAR.: |                 |");
                                System.out.println("*-------------*                 |");
                                System.out.println("| => Nome               (1)     |");
                                System.out.println("| => Codigo do Produto  (2)     |");
                                System.out.println("| => Preço              (3)     |");
                                System.out.println("| => Sair               (0)     |"); 
                                System.out.println("*-------------------------------*");
                                
                                System.out.print("OPÇÃO MODIFICAR.: ");
                                opcaomodificar=Ler.umInt();
                                 System.out.println(limpar);//limpa o output
                                
                                
                                
                                
                                if(opcaomodificar==1){
                                    System.out.println(limpar);//limpa o output
                                    System.out.print("Código.:");
                                    int modificar=Ler.umInt();
                                    System.out.println("Nome antigo => "+lojaprodutos.NomeaPartirdeCodigo(modificar));
                                    System.out.print("Novo Nome do Produto.: ");
                                    String novonome=Ler.umaString();
                                    lojaprodutos.alterarNome(modificar, novonome);
                                }
                                
                                if(opcaomodificar==2){
                                    System.out.println(limpar);//limpa o output
                                    System.out.print("Código.:");
                                    int modificar=Ler.umInt();
                                    System.out.println("Codigo Antigo => "+modificar);
                                    System.out.print("Novo Código.: ");
                                    int novocodigo=Ler.umInt();
                                    lojaprodutos.alteraCodigo(modificar, novocodigo);
                                
                                }
                                
                                if(opcaomodificar==3){
                                    System.out.println(limpar);//limpa o output
                                    System.out.print("Código.:");
                                    int modificar=Ler.umInt();
                                    System.out.println("Preço Antigo => "+lojaprodutos.encontrarPreco(modificar));
                                    System.out.print("Novo Preço.: ");
                                    int novopreco=Ler.umInt();
                                    lojaprodutos.alteraPreço(modificar, novopreco);
                                
                                }
                               
                                }
                                break;
                                
                                
                                
                            case 4:
                               
                                int opcaoeliminar=190;
                                 while(opcaoeliminar!=0){
                                 System.out.println(limpar);//limpa o output
                                System.out.println("*------------*------------------*");     
                                System.out.println("|ELIMINAR.:  |                  |");
                                System.out.println("*------------*                  |");
                                System.out.println("| => Eliminar lote      (1)     |");
                                System.out.println("| => Eliminar Produto   (2)     |");
                                System.out.println("| => Sair               (0)     |");
                                System.out.println("*-------------------------------*");
                                
                                System.out.print("OPCÃO ELIMINAR.: ");
                                opcaoeliminar=Ler.umInt();
                                System.out.println(limpar);//limpa o output
                                if(opcaoeliminar==1){
                                    System.out.println(limpar);//limpa o output
                                    System.out.print("Código do lote a Eliminar.: ");
                                    int loteeliminar=Ler.umInt();
                                    lojaprodutos.eliminarLote(loteeliminar);
                                
                                }
                                
                                if(opcaoeliminar==2){
                                    System.out.println(limpar);//limpa o output
                                    System.out.print("Código de barras do Produto a Eliminar.:");
                                    int produtoeliminar=Ler.umInt();
                                    lojaprodutos.removeProduto(produtoeliminar);
                                
                                }
                                
                               
                                 }
                                
                                
                                break;
                        //*********************  FIM CASE 2 PRODUTOS ***************************

                            //************************* CASE 3 PRODUTOS ****************************
                            case 5:
                                String produtoexiste = " ";
                                System.out.print("\nIntroduza o Nome do Produto.: ");
                                produtoexiste = Ler.umaString();
                                if (lojaprodutos.verificaNome(produtoexiste)) {
                                    System.out.println("O Produto => " + produtoexiste + ", existe na loja. ");
                                }

                                if (lojaprodutos.verificaNome(produtoexiste) == false) {
                                    System.out.print("O Produto => " + produtoexiste + ", não existe na loja. ");
                                }

                                break;
                        //********************  FIM DO CASE 3 PRODUTOS ******************************

                            //********************* Case 4 PRODUTOS  ************************************
                            case 6:
                                lojaprodutos.Stock();
                                System.out.println(lojaprodutos.ListadeStock());

                                break;

                       //******************** FIM DO CASE 4 PRODUTOS ********************************
                            //********************* CASE 0 PRODUTOS **************************************
                            case 0:
                                continuarprodutos = "N";
                                break;
                       //********************* FIM DO CASE 0 PRODUTOS ********************************

                        }
                        // FIM DO SWITCH DE MENU PRODUTOS
                        if (menuprodutos != 0) {// só pergunta quando não for selecionado a opçao de sair
                         
                           System.out.print("\nQuer Continuar Na Opção PRODUTOS (Y/N).: ");
                            continuarprodutos = Ler.umaString();// Pergunta se quer continuar no menu produtos
                        }
                    }

                    break;

                //---------------------- FIM DO CASE 1 MENU INICIAL -----------------------------------
                //---------------------- CASE 2 CLIENTES -----------------------------------------------
                case 2:
                    int menuclientes;
                    String continuarclientes = " ";
                    while (continuarclientes.compareTo("N") != 0) {// vai ver se quer sair do menu produtos

                        System.out.println(limpar);//limpa o output 
                        
                        System.out.println("*------------------*-------------------*");
                        System.out.println("| OPCÕES CLIENTE.: |                   |");
                        System.out.println("*------------------*                   |");
                        System.out.println("|   => Adicionar Novo Cliente  (1)     |");
                        System.out.println("|   => Remover Cliente         (2)     |");
                        System.out.println("|   => Modificar dados Cliente (3)     |");
                        System.out.println("|   => Ver Lista de Clientes   (4)     |");
                        System.out.println("|   => Cliente Registado?      (5)     |");
                        System.out.println("|   => Melhor Cliente          (6)     |");
                        System.out.println("|   => Sair do menu Cliente    (0)     |");
                        System.out.println("*---+---+---+---+---+---+---+---+---+--*");
                        System.out.print("OPCÃO CLIENTES.: ");
                        menuclientes = Ler.umInt();// ve a opcao escolhida

                        System.out.println(limpar);//limpa o output   

                        switch (menuclientes) {
                            //-----------------------  CASE 1 CLIENTES -----------------------------
                            case 1:
                                //INTRODUZIR PRODUTOS
                                String continuar = "";
                                while (continuar.compareTo("N") != 0) {
                                    System.out.println(limpar);//limpa o output   

                                    Ficha novocliente;
                                    String nome = "";
                                    long nif, contacto;

                                    System.out.print("\nNome.: ");//pede o Nome
                                    nome = Ler.umaString();
                                    System.out.print("NIF.: ");//pede o NIF
                                    nif = Ler.umLong();
                                    System.out.print("Contacto.: ");//pede o Contacto
                                    contacto = Ler.umLong();

                                    novocliente = new Ficha(nome, nif, contacto);// introduz o pedido no objecto Ficha
                                    clientesloja.adicionaCliente(novocliente);

                                    System.out.print("\nContinuar a Introduzir CLIENTES (Y/N): ");
                                    continuar = Ler.umaString();

                                    System.out.println(limpar);//limpa o output   
                                    //----------------------------------------------------------------
                                }
                                break;
                                
                            case 2:
                                System.out.print("Introduza o NIF do Cliente.: ");
                                long nifremover=Ler.umLong();
                                System.out.println(limpar);//limpa o output  
                                System.out.println("Cliente Removido.: \n"+clientesloja.dadosCliente(nifremover));
                                clientesloja.removeClienteNif(nifremover);
                                
                                break;
                                
                            case 3:
                                long alterardados=0;
                                int opcaomodificar=190;
                                while(opcaomodificar!=0){
                                System.out.println(limpar);//limpa o output
                                System.out.println("*-------------*-----------------*");     
                                System.out.println("| MODIFICAR.: |                 |");
                                System.out.println("*-------------*                 |");
                                System.out.println("| => Alterar Nome       (1)     |");
                                System.out.println("| => Alterar Contacto   (2)     |");
                                System.out.println("| => Alterar Nif        (3)     |");
                                System.out.println("| => Sair               (0)     |");
                                System.out.println("*-------------------------------*");
                                
                                System.out.print("OPÇÃO MODIFICAR.:");
                                opcaomodificar=Ler.umInt();
                                System.out.println(limpar);//limpa o output
                                
                              
                                
                                if(opcaomodificar==1){
                                    System.out.print("Introduza o NIF.: ");
                                    alterardados=Ler.umLong();
                                    System.out.println(limpar);//limpa o output
                                    System.out.println("Nome a Modificar => "+clientesloja.devolveNome(alterardados));
                                    System.out.print("Nome Modificado.: ");
                                    String nomemodificado=Ler.umaString();
                                    clientesloja.alteraNome(alterardados, nomemodificado);
                               
                                }
                                
                                if(opcaomodificar==2){
                                    System.out.print("Introduza o NIF.: ");
                                    alterardados=Ler.umLong();
                                    System.out.println(limpar);//limpa o output
                                    System.out.println("Contacto a Modificar => "+clientesloja.devolveContacto(alterardados));
                                    System.out.print("Contacto Modificado.: ");
                                    long contactonovo=Ler.umLong();
                                    clientesloja.alteraContacto(alterardados, contactonovo);
                                
                                }
                                
                                if(opcaomodificar==3){
                                    System.out.print("Introduza o NIF.: ");
                                    alterardados=Ler.umLong();
                                    System.out.println(limpar);//limpa o output
                                    System.out.println("Nif a Modificar => "+alterardados);
                                    System.out.print("Nif Modificado.: ");
                                    long nifmodificado=Ler.umLong();
                                    clientesloja.alteraNif(alterardados, nifmodificado);
                                
                                }
                                
                                }
                                break;
                        //*********************  FIM CASE 1 CLIENTES  **************************

                            //********************** CASE 2 CLIENTES  ******************************
                            case 4:
                                System.out.println(clientesloja.toString());
                                break;
                        //*********************  FIM CASE 2 CLIENTES ***************************

                            //************************* CASE 3 CLIENTES ****************************
                            case 5:
                                long nifexiste = 0;
                                System.out.print("\n Introduza o NIF do Cliente.: ");
                                nifexiste = Ler.umLong();
                                if (clientesloja.verificaNIF(nifexiste)) {
                                    System.out.println("O Cliente já está => REGISTADO <=");
                                }

                                if (clientesloja.verificaNIF(nifexiste) == false) {
                                    System.out.print("O Cliente ainda => NÃO ESTÁ REGISTADO <=");
                                }
                                break;
                        //********************  FIM DO CASE 3 CLIENTES ******************************

                            //********************* Case 4 CLIENTES  ************************************
                            case 6:
                                double melhor=0.0;// valor de compras do melhor cliente
                                String melhorcliente="";// guarda o nome do melhor
                                for(int i=0;i<clientesloja.clientes.size();i++){// percorre os clientes
                                    if(clientesloja.clientes.get(i).getComprasEfectuadas() > melhor){//quando o valor do cliente for maior que o melhor 
                                        melhor=clientesloja.clientes.get(i).getComprasEfectuadas();// quarda o total de compras efectuadas do melhor
                                        melhorcliente="Nome.: "+clientesloja.clientes.get(i).getNome()+"\nNIF.: "+// e o seu nome,nif e totaldecomprasefectuadas na string 
                                                clientesloja.clientes.get(i).getNif()+"\nTotal de Compras.: "+melhor;   
                                    }
                                
                                }
                                    System.out.println(melhorcliente);// imprime o melhor cliente 
                                    
                                break;

                       //******************** FIM DO CASE 4 CLIENTES ********************************
                            //********************* CASE 0 CLIENTES **************************************
                            case 0:
                                continuarclientes = "N";
                                break;
                       //********************* FIM DO CASE 0 CLIENTES ********************************                       //********************* FIM DO CASE 0 PRODUTOS ********************************

                        }
                        // FIM DO SWITCH DE MENU CLIENTES
                        if (menuclientes != 0) {// só pergunta quando não for selecionado a opçao de sair
                          
                            System.out.print("\nQuer Continuar Na Opção CLIENTES (Y/N).: ");
                            continuarclientes = Ler.umaString();// Pergunta se quer continuar no menu clientes
                        }
                    }//Fecha o ciclo while do menu clientes
                    break;// FIM DO CASE 2(CLIENTES) MENU INICIAL

//------------------------- CASE 3 FATURAÇÃO -----------------------------------------------------------------  
                case 3:
                    int menufatura;
                    String continuarfatura = " ";
                    while (continuarfatura.compareTo("N") != 0) {// vai ver se quer sair do menu produtos

                        System.out.println(limpar);//limpa o output
                        System.out.println("*--------------------*-----------------*");
                        System.out.println("| OPCÕES FATURAÇÃO.: |                 |");
                        System.out.println("*--------------------*                 |");
                        System.out.println("| => Nova Fatura             (1)       |");
                        System.out.println("| => Lista de Faturas        (2)       |");
                        System.out.println("| => Ver Fatura              (3)       |");
                        System.out.println("| => Anular Fatura           (4)       |");
                        System.out.println("| => Total Faturado          (5)       |");
                        System.out.println("| => Sair do menu Fatura     (0)       |");
                        System.out.println("*--------------------------------------*");

                        System.out.print("OPCÃO FATURAÇÃO.: ");
                        menufatura = Ler.umInt();// ve a opcao escolhida

                        System.out.println(limpar);//limpa o output   

                        switch (menufatura) {
//******************************* INICIO DO CASE 1 FATURACAO ***********************************
                            case 1:

                                Fatura nova;//inicializar nova fatura
                                System.out.print("Introduza o NIF.: ");
                                long ncliente = Ler.umLong();// recebe o numero do cliente
                                if(clientesloja.verificaNIF(ncliente)==false){
                                    
                                    System.out.print("\nNome.: ");//pede o Nome
                                     String nome = Ler.umaString();
                                    System.out.print("Contacto.: ");//pede o Contacto
                                     long contacto = Ler.umLong();

                                    Ficha novocliente = new Ficha(nome, ncliente, contacto);// introduz o pedido no objecto Ficha
                                    clientesloja.adicionaCliente(novocliente);
                                
                                }
                               
                                System.out.println(limpar);//limpa o output 

                                nova = new Fatura(ncliente, clientesloja,lojaprodutos);// cria a fatura com o numero de cliente e recebe a lista de clientes para escrever os dados do cliente
                                String introduzproduto = " ";
                                nova.DataFatura(dia, mes, ano);

                                System.out.println("Produtos.: ");
                                while (introduzproduto.compareTo("N") != 0) {

                                    System.out.println(limpar);//limpa o output
                                    int codigocompra=9999999;
                                    while(lojaprodutos.verificaCodigoBarras(codigocompra)!=true){
                                    System.out.print("Introduza o código de Barras: ");
                                    codigocompra = Ler.umInt();
                                    }
                                    nova.insereProduto(codigocompra);//VERRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                                    
                                    System.out.println(limpar);//limpa o output
                                    
                                    lojaprodutos.removeProduto(codigocompra);
                                    System.out.print("Deseja itroduzir mais PRODUTOS (Y/N)");
                                    introduzproduto = Ler.umaString();// ver se quer continuar a introduzir produtos para parar o while
                                }
                                
                                   for (int i = 0; i < clientesloja.clientes.size(); i++) {// percorre os clientes
                                    if (clientesloja.clientes.get(i).getNif() == ncliente) {//quando o nif for igual 
                                        clientesloja.clientes.get(i).adicionaCompra(nova.getTotaldafatura());//adiciona o total da fatura as compras efecuadas do cliente
                                        
                                    }
                                }
                                System.out.println(lojaprodutos.avisodeStock());
                                faturasloja.adicionarFatura(nova);// adiciona a fatura á lista de faturas
                                 
                                for(int i=0;i<clientesloja.clientes.size();i++){// percorre a lista de clientes
                                    if(clientesloja.clientes.get(i).getNif()==ncliente){// quando o nif for igual ao introduzido
                                        clientesloja.clientes.get(i).adicionaCompra((double) nova.calculaTotal());// adiciona-se o valor da fatura ás compras efect
                                    }
                                        }
                                break;
      //******************************* FIM DO CASE 1 FATURACAO *********************************** 
     // ******************************* INICIO DO CASE 2 FATURACAO *****************************
                            case 2:
                                System.out.println(faturasloja.mostraFaturas());
                                
                                break;
                            
                            
                           
                            
                            case 3:
                                
                                int numerofatura=9999999;
                                
                                
                                do {
                                    System.out.print("Introduza o numero da Fatura:");
                                    numerofatura=Ler.umInt();}
                                while(numerofatura>faturasloja.faturacao.size());
                             
                                
                                System.out.println(faturasloja.verFatura(numerofatura));
                                
                                
                                break;
//******************************* FIM DO CASE 2 FATURACAO ***********************************
                                
// ******************************* INICIO DO CASE 3 FATURACAO *****************************
                            case 4:
                                System.out.print("Introduza o numero da fatura.:");
                                int elimina = Ler.umInt();
                                faturasloja.AnulaFatura(elimina);

                                break;

//******************************* FIM DO CASE 3 FATURACAO *********************************** 
// ******************************* INICIO DO CASE 3 FATURACAO *****************************
                            case 5:
                                System.out.println("TOTAL FATURADO =>> " + faturasloja.totalFaturado());
                                break;
                                
                            case 0:
                                continuarfatura="N";
                                break;

//******************************* FIM DO CASE 3 FATURACAO ***********************************   
                        }//FIM DO SWITCH FATURACAO(CASE 3).
                        if (menufatura != 0) {// só pergunta quando não for selecionado a opçao de sair
                            System.out.print("\nQuer Continuar Na Opção FATURAÇÃO (Y/N).: ");
                            continuarfatura = Ler.umaString();// Pergunta se quer continuar no menu  faturacao
                        }
                       
                    }//Fecha o ciclo WHILE do menu faturação
                 break;//FIM DO CASE FATURACAO
                    

//----------------------------- FIM DO CASE 3(FATURAÇAO) MENU INICIAL ----------------------------------
                
//--------------------------- INICIO DO CASE 4(VENDAS) MENUINICIAL ----------------------------------------                
                case 4:
                    System.out.println(limpar);//limpa o output
                    int menuvendas=90;
                    String continuarvendas = " ";
                    while (continuarvendas.compareTo("N") != 0) {// vai ver se quer sair do menu vendas
                    
                       System.out.println(limpar);//limpa o output
                        System.out.println("*-----------------*--------------------*");
                        System.out.println("| OPCÕES VENDAS.: |                    |");
                        System.out.println("*-----------------*                    |");
                        System.out.println("| => Total Faturado do Dia   (1)       |");
                        System.out.println("| => Total Faturado do Mes   (2)       |");
                        System.out.println("| => Total Faturado do Ano   (3)       |");
                        System.out.println("| => Total  Faturado         (4)       |");
                        System.out.println("| => Sair do menu Vendas     (0)       |");
                        System.out.println("*--------------------------------------*");

                        System.out.print("OPCÃO VENDAS.: ");
                        menuvendas = Ler.umInt();// ve a opcao escolhida

                        System.out.println(limpar);//limpa o output

                        switch (menuvendas) {
                            case 1:
                                
                                System.out.println("Total de Vendas do Dia.: "+faturasloja.TotalVendasDoDia(dia,mes, ano)+"€");
                               
                                break;
                               
                            case 2:
                                
                                    
                                System.out.println("Total de Vendas do Mês.: "+faturasloja.TotalVendasDoMes(mes, ano)+"€");
                                break;
                                
                            case 3:
                               System.out.println("Total de Vendas do Ano.: "+faturasloja.TotalVendasDoAno(ano)+"€");
                                break;
                                
                            case 4:
                                System.out.println("Total Faturado.: "+faturasloja.totalFaturado()+"€");
                                break;
                                
                                
                            case 0:
                                continuarvendas="N";
                                break;
                                
                            
                        }
                        
                        if (menuvendas != 0) {// só pergunta quando não for selecionado a opçao de sair
                          
                            System.out.print("\nQuer Continuar Na Opção VENDAS (Y/N).: ");
                            continuarvendas = Ler.umaString();// Pergunta se quer continuar no menu Vendas
                        }
                    
                    }
                        
                    break;
//----------------------------- FIM DO CASE 4(VENDAS) MENU INICIAL ----------------------------------           
            
            }

        }//Fecha o while do menuinicial
       try{
        ObjectOutputStream ficheiroprodutos = new ObjectOutputStream (new FileOutputStream("lojaprodutos.txt"));
        ObjectOutputStream ficheiroclientes = new ObjectOutputStream (new FileOutputStream("lojaclientes.txt"));
        ObjectOutputStream ficheirofaturas = new ObjectOutputStream (new FileOutputStream("lojafaturas.txt"));
        
        
        ficheiroprodutos.writeObject(lojaprodutos);
        ficheiroclientes.writeObject(clientesloja);
        ficheirofaturas.writeObject(faturasloja);
        
        
        
        ficheiroprodutos.flush();
        ficheiroclientes.flush();
        ficheirofaturas.flush();
        
        ficheiroprodutos.close();
        ficheiroclientes.close();
        ficheirofaturas.close();
       
 
        } catch (Exception e) {
             e.printStackTrace();
        } 
    }
        


    

    public static String limpaOutput() {
        String limpa = "";
        for (int i = 0; i < 100; i++) {
            limpa = limpa + "\n";
        }
        return limpa;
    } 
    
    public static boolean anoBicesto(int ano){
        
        if(ano % 400 == 0){
        return true;
        } 
        else if((ano % 4 == 0) && (ano % 100 != 0)){
            return true;
        } 
    
    return false;
    }
    
    public static int diasMes(int mes){
        int dias=31;
        switch( mes )
        {
            // fevereiro: subtraímos 2 dias aqui e 1 dia no próximo case
            case 2: 
                dias -=2;
                
            //meses que possuem 30 dias: só subtraímos 1 dia
            case 4: case 6: case 9: case 11:
                dias--;

        }
   return dias;
    }
    
    
    public static void escrever(ListadeProdutos func,String nomeficheiro)  {
       try{
        ObjectOutputStream file = new ObjectOutputStream (new FileOutputStream(nomeficheiro));
  
        
            file.writeObject(func);
 
        } catch (Exception e) {
 
            e.printStackTrace();
        } 
    }
       
    

}
