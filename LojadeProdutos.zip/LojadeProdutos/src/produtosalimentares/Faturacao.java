/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package produtosalimentares;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author JorgeRodrigues
 */
public class Faturacao implements Serializable {
    protected ArrayList<Fatura> faturacao;
    private long contador;
    
    public Faturacao(){
        faturacao=new ArrayList<Fatura>();
        this.contador=0;
    }

    public void setContador(long contador) {
        this.contador = contador;
    }
    
  
    
    public void setFaturacao(ArrayList<Fatura> faturacao){
        this.faturacao=faturacao;
    }
    
    public ArrayList<Fatura> getFaturacao(){
        return faturacao;
    }

    public long getContador() {
        return contador;
    }
    
    public String verFatura(int numerofatura){
        String fatura;
        fatura=faturacao.get(numerofatura-1).toString();// mostra a fatura da posição introduzida
       return fatura;
    }
    
   public long getUltimoNumero(){
       long ultimo = faturacao.get(faturacao.size()).getNumero();
   
       return ultimo;
   }
    
    public void imprimirFatura(int numerofatura){
        
    
    
    }
    
    public double totalFaturado(){
        double totalfaturado=0.0;
        
        for(int i=0;i<faturacao.size();i++){
            totalfaturado=totalfaturado+faturacao.get(i).getTotaldafatura();

        }
    
        return totalfaturado;
    }
    
    public void AnulaFatura(int numero){
        faturacao.get(numero-1).setAno(0);
        faturacao.get(numero-1).setCliente(null);
        faturacao.get(numero-1).setDia(0);
        faturacao.get(numero-1).setMes(0);
        faturacao.get(numero-1).setProdutos(null);
        faturacao.get(numero-1).setProdutosparaselecao(null);
        faturacao.get(numero-1).setTotaldafatura(0);
    }
    
    public String TotalVendasDoMes(int mes,int ano){
         
        double vendas=0;  
        String vendasformatado="";
        for(int i=0;i<faturacao.size();i++){
            if(faturacao.get(i).getMes()==mes && faturacao.get(i).getAno()==ano){
                vendas=vendas+faturacao.get(i).getTotaldafatura();
            }
        }
        vendasformatado=vendasformatado.format("%.2f",(vendas));
        return vendasformatado;
    }
    
    
     public String TotalVendasDoDia(int dia,int mes,int ano){
         double vendas=0;
         String vendasformatado="";
        for(int i=0;i<faturacao.size();i++){
            if(faturacao.get(i).getMes()==mes && faturacao.get(i).getAno()==ano && faturacao.get(i).getDia()==dia){
                vendas=vendas+faturacao.get(i).getTotaldafatura();
            }
        }
   
        vendasformatado=vendasformatado.format("%.2f",(vendas));
        return vendasformatado;
    }
     
     public String TotalVendasDoAno(int ano){
         double vendas=0;
         String vendasformatado="";
        for(int i=0;i<faturacao.size();i++){
            if(faturacao.get(i).getAno()==ano){
                vendas=vendas+faturacao.get(i).getTotaldafatura();
            }
        }
    vendasformatado=vendasformatado.format("%.2f",(vendas));
        return vendasformatado;
        
    }
     
     
     public void setultimoNumero(long ultimo){
         faturacao.get(faturacao.size()).setNumero(ultimo);
     }
    
    public String ProdutodoMes(int mes,int ano,Faturacao loja){
        String produtomessaida="";
        int [] produtomes=new int[999999];
        int maior=0;
        for(int i=0;i<faturacao.size();i++){
            if(faturacao.get(i).getMes()==mes && faturacao.get(i).getAno()==ano){
                int codigo=loja.getFaturacao().get(i).getProdutos().get(i).getCodigo();
                produtomes[codigo]=produtomes[codigo]+1;
            }
        }
        
        for(int i=0;i<produtomes.length;i++){
            if(produtomes[i]!=0){
                
                if(produtomes[i]>maior){
                    produtomessaida=loja.getFaturacao().get(i).getProdutos().get(i).getProduto();
                    maior=produtomes[i];
                
                }
            }
        
        }
    
    
    return produtomessaida;
    }
    
    
    public String mostraFaturas(){
        String mostrafaturas="";
            for(int i=0;i<faturacao.size();i++){
            mostrafaturas=mostrafaturas+"Numero.: "+faturacao.get(i).getNumero()
                    +"| Data.: "+faturacao.get(i).getDia()+"/"+
                    faturacao.get(i).getMes()+"/"+
                    faturacao.get(i).getAno()+"| Total.: "+faturacao.get(i).getTotaldafatura()+"\n";
                    
            
            }
    
    return mostrafaturas;
    }
    

    

            
    
    public void adicionarFatura(Fatura entrada){
        this.contador=contador+1;
        faturacao.add(entrada);
        faturacao.get(faturacao.size()-1).setNumero(contador);
    }
   
    public String toString(){
    String faturasloja="";
        for(int i=0;i<faturacao.size();i++){
            faturasloja=faturasloja+faturacao.get(i)+"\n";
        }
        return " >>>>>> Faturas da Loja <<<<<< "+faturasloja;
    }
}
