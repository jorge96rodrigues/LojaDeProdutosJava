package produtosalimentares;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author JorgeRodrigues
 */
public class Fatura implements Serializable  {
    private long numero=0;// numero da fatura
    private String cliente;// dados do cliente
    private ArrayList<Produto> produtos;// produtos da fatura
    private double totaldafatura;// total da fatura €
    private ArrayList<Produto> produtosparaselecao;
    private int dia;// dia da fatura
    private int mes;//mes
    private int ano;//ano
    

// Construtor  
    public Fatura(long nif, Clientes lista, ListadeProdutos a) {
        this.produtosparaselecao=(ArrayList<Produto>)a.listadeprodutos.clone();
        this.numero=0;
        this.cliente = lista.dadosCliente(nif);
        this.produtos = new ArrayList<Produto>();
        this.totaldafatura = 0;
        this.dia=0;
        this.mes=0;
        this.ano=0;
        
        
    } 
//------------------------------------------------------------------------------
//set's

   

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setTotaldafatura(double totaldafatura) {
        this.totaldafatura = totaldafatura;
    }

    public void setProdutosparaselecao(ArrayList<Produto> produtosparaselecao) {
        this.produtosparaselecao = produtosparaselecao;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    public void setProdutos(ArrayList<Produto> produtos) {
        this.produtos = (ArrayList<Produto>) produtos.clone();
    }
//------------------------------------------------------------------------------
//get's

    public String getCliente() {
        return cliente;
    }
    
   

    public long getNumero() {
        return numero;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public double getTotaldafatura() {
        return totaldafatura;
    }

    public ArrayList<Produto> getProdutosparaselecao() {
        return produtosparaselecao;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAno() {
        return ano;
    }
//------------------------------------------------------------------------------
//Calcula o total

    public double calculaTotal() {
        for (int i = 0; i < produtos.size(); i++) {
            if(produtos.get(i)!=null){
            this.totaldafatura = (totaldafatura + produtos.get(i).getPreco());
            }
            
        }
        
        this.totaldafatura=totaldafatura+((totaldafatura*6)/100);
        return totaldafatura;
    }
    
    
   
    
//Introduz a data
 public void DataFatura(int dia,int mes,int ano){
     this.dia=dia;
     this.mes=mes;
     this.ano=ano;
 }
//------------------------------------------------------------------------------
// verifica se o produto já existe 

    public boolean verificaProduto(Produto a) {
        for (int i = 0; i < produtos.size(); i++) {
            if (produtos.get(i).equals(a)) {
                return true;
            }
        }
        return false;
    }
//------------------------------------------------------------------------------    
//insere produto
    public void insereProduto(int codigodebarras){
        for(int i=0;i<produtosparaselecao.size();i++){
        
            if(produtosparaselecao.get(i).getCodigodebarras()==codigodebarras){
                    produtos.add(produtosparaselecao.get(i));
                    
                }
        }
    }
//------------------------------------------------------------------------------
// metodo toString

    public String toString() {
        
        String listaprodutos = "";
        for (int i = 0; i < produtos.size(); i++) {
            listaprodutos = listaprodutos + "=> Produto.: "+produtos.get(i).getProduto()+" | "
           +"Código.: "+produtos.get(i).getCodigo()+" | "+"Preço.: "+produtos.get(i).getPreco() + 
                    "  €\n";
        }
        double periva=(totaldafatura*6)/100;
        String iva="";
        iva=iva.format("%.2f", periva);
        
        String totalliquido="";
        totalliquido=totalliquido.format("%.2f", (totaldafatura-periva));
        String totalfatura="";
        totalfatura=totalfatura.format("%.2f",(totaldafatura));

        return "***********************************************************************\n"
                + "Fatura nº.: " + numero + "\n"
                + "***********************************************************************\n"
                + "Data.: "+dia+"/"+mes+"/"+ano+"\n"
                + "***********************************************************************\n"
                + "Dados do Cliente.: \n"
                + "-----------------------------------------------------------------------\n"
                + cliente
                + "\n***********************************************************************\n"
                + "Produtos.: \n"
                + "-----------------------------------------------------------------------\n"
                +  listaprodutos
                + "***********************************************************************\n"
                + "TOTAL LIQUIDO.:"+totalliquido+" | IVA(6%).: " +iva+"€ | TOTAL.: "+totalfatura+"\n"
                + "***********************************************************************\n";
             

    }
//------------------------------------------------------------------------------

}
